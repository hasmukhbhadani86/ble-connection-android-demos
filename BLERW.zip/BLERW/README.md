BLERW
=====

Android BLE Scan and Characteristics Read/Write Example

![Figure 1 ScanActivity for BLE Scan](etc/BLERW_cap01.png) 
![Figure 2 DeviceActivity for Read/Write Characteristics](etc/BLERW_cap02.png)

# License

Apache License Version 2.0
